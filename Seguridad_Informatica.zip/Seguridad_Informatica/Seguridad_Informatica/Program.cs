﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Seguridad_Informatica
{
	class Program
	{
		//Variable donde almacenamos las letras del abecedario
		static string bagheera = "abcdefghijklmñnopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ";

		//Método para cifrar el msj
		static string baloo(string msj, int akera)
		{
			//Variable para guardar el mensaje ingresado
			String cifrado = "";
			
			//Condición para el dezplazamiento de variable
			if (akera > 0 && akera < bagheera.Length)
			{
				//Ciclo que recorre caracter por caracter el mensaje ingresado
				for (int i = 0; i < msj.Length; i++)
				{
					int posCaracter = getPosABC(msj[i]);
					//Condición para saber si el caracter existe en la variable bagheera

					if (posCaracter != -1) 
					{
						int pos = posCaracter + akera;
						while (pos >= bagheera.Length)
						{
							pos = pos - bagheera.Length;
						}
					
						//Concatena el msj codificado
						cifrado += bagheera[pos];
					}
					
					//Si la condición anterior no se cumple, no se codifica el mensaje
					else
					{
						cifrado += msj[i];
					}
				}

			}
			return cifrado;
		}

		//Método para descifrar el mensaje ingresado
		static string mowgli(string msj, int akera)
		{
			//Variable para guardar el mensaje ingresado
			String cifrado = "";

			//Condición para el dezplazamiento de variable
			if (akera > 0 && akera < bagheera.Length)
			{
				//Ciclo que recorre caracter por caracter el mensaje ingresado
				for (int i = 0; i < msj.Length; i++)
				{
					int posCaracter = getPosABC(msj[i]);

					//Condición que indica si el caracter existe en la variable bagheera
					if (posCaracter != -1) 
					{
						int pos = posCaracter - akera;
						while (pos < 0)
						{
							pos = pos + bagheera.Length;
						}
						cifrado += bagheera[pos];
					}
					else
					{
						cifrado += msj[i];
					}
				}

			}
			return cifrado;
		}

		//Método para obtener la posición del caracter anterior 
		static int getPosABC(char caracter)
		{
			for (int i = 0; i < bagheera.Length; i++)
			{
				if (caracter == bagheera[i])
				{
					return i;
				}
			}
			return -1;
		}

		//Mandamos a llamar a los métodos
		static void Main(string[] args)
		{
			String msj;
			Console.WriteLine("Ingrese el msj (Solo letras): ");
			msj = Console.ReadLine();

			//se codifica el mensaje ingresado
			string tmp = baloo(msj, 10);

			//se visualiza en pantalla
			Console.WriteLine("Mensaje cifrado: " + tmp); 

			//se descifra el mensaje ingresado
			Console.WriteLine("Mensaje descifrado: " + mowgli(tmp, 10));

			Console.ReadKey();
		}
	}
}
